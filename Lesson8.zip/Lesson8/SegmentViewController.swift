//
//  SegmentViewController.swift
//  Lesson8
//
//  Created by Татьяна Борисова on 12.10.2021.
//

import UIKit

class SegmentViewController: UIViewController {
    
    @IBOutlet weak var tf1: UITextField!
    
    @IBOutlet weak var tf2: UITextField!
    
    @IBOutlet weak var but1: UIButton!
    
    
    @IBOutlet weak var but2: UIButton!
    
    
    @IBOutlet weak var image1: UIImageView!
    
    
    @IBOutlet weak var image2: UIImageView!
    
    @IBOutlet weak var sc: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkSc(segmentIndex: sc.selectedSegmentIndex)
        // Do any additional setup after loading the view.
    }
    
    @IBAction func scAction(_ sender: UISegmentedControl) {
        checkSc(segmentIndex: sc.selectedSegmentIndex)
    }
    
    func checkSc (segmentIndex: Int) {
        tf1.isHidden = true
        tf2.isHidden = true
        but1.isHidden = true
        but2.isHidden = true
        image1.isHidden = true
        image2.isHidden = true
        switch segmentIndex {
        case 0:
            tf1.isHidden = false
            tf2.isHidden = false
            self.view.backgroundColor = .green
        case 1:
            but1.isHidden = false
            but2.isHidden = false
            self.view.backgroundColor = .blue
        case 2:
            image1.isHidden = false
            image2.isHidden = false
            self.view.backgroundColor = .purple
        default:
            break
        }
    }
    
    
    
}

