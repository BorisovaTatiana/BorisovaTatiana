//
//  FourPicturesViewController.swift
//  Lesson8
//
//  Created by Татьяна Борисова on 12.10.2021.
//

import UIKit

class FourPicturesViewController: UIViewController {

    @IBOutlet var imageArray: [UIImageView]!
    
    @IBOutlet var labelArray: [UILabel]!
    
    var imageNames = ["i0","i1","i9","i3"]
    var imageCostNames = [100,200,300,400]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setImage()
    }
    func setImage () {
        for index in 0..<imageArray.count {
            imageArray[index].image = UIImage(named: imageNames[index])
            labelArray[index].text = "Цена \(imageCostNames[index])"
        }
    }

}
