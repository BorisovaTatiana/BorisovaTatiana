//
//  ViewController.swift
//  Lesson8
//
//  Created by Татьяна Борисова on 12.10.2021.
//

import UIKit
class ViewController: UIViewController {

    @IBOutlet weak var myImageView: UIImageView!
    
    @IBOutlet weak var myLabel: UILabel!
    
    let imageArray = ["i0","i1","i2","i3","i4","i5","i6","i7","i8","i9"]
    var index = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myLabel.text = "Картинка \(index)"
        myImageView.image = UIImage(named: imageArray.first!)
    }
    func checkIndex() {
        myLabel.text = "Картинка \(index)"
        if index < 0 {
            myLabel.text = "Вы дошли до первой картинки!"
            index = 0
        } else if index >= imageArray.count {
            myLabel.text = "Вы дошли до последней картинки!"
            index = imageArray.count - 1
        }
       
    }
    

    @IBAction func backButton(_ sender: UIButton) {
        index -= 1
        checkIndex()
        myImageView.image = UIImage(named: imageArray[index])
    }
    
    @IBAction func goButtonTab(_ sender: UIButton) {
        index += 1
        checkIndex()
        myImageView.image = UIImage(named: imageArray[index])
    }
}

